import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';  // useNavigate import করুন
import axios from 'axios';
import { useCart } from '../context/CartContext';
import './Home.css';

const ProductDetail = () => {
  const { productId } = useParams();
  const navigate = useNavigate();  // navigate হুক নিন
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  const { addToCart } = useCart();

  useEffect(() => {
    axios
      .get(`http://localhost/ecommerce-backend/get-product.php?id=${productId}`)
      .then(res => {
        setProduct(res.data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [productId]);

  if (loading) return <p>Loading...</p>;
  if (!product) return <p>Product not found</p>;

  const handleAddToCart = () => {
    addToCart(product);
    alert('✅ Product added to cart!');
    navigate('/cart');  // Add to Cart এর পর সরাসরি Cart পেজে নিয়ে যাবে
  };

  return (
    <div className="product-detail-container">
      <h1>{product.name}</h1>
      <img
        src={`http://localhost/ecommerce-backend/${product.image}`}
        alt={product.name}
      />
      <p>{product.description}</p>
      <h2>৳{Number(product.price).toFixed(2)}</h2>
      <button onClick={handleAddToCart}>Add to Cart</button>
    </div>
  );
};

export default ProductDetail;

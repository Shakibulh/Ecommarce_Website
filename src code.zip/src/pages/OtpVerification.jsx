import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./ForgetPassword.css";


const OtpVerification = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || "";

  const [otp, setOtp] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  if (!email) {
    navigate("/forget-password");
  }

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (otp.length !== 6) {
      setError("Please enter valid 6-digit OTP");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch("http://localhost/ecommerce-backend/verify_otp.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp }),
      });

      const data = await res.json();

      if (data.success) {
        alert("OTP Verified! Now set your new password.");
        navigate("/reset-password", { state: { email } });
      } else {
        setError(data.error || "Invalid OTP");
      }
    } catch {
      setError("Server error. Try again.");
    }
    setLoading(false);
  };

  return (
    <div className="forget-container">
      <form className="forget-form" onSubmit={handleSubmit}>
        <h2 className="form-title">Verify OTP</h2>
        <p className="form-subtitle">Enter the 6-digit OTP sent to your email</p>

        <input
          type="text"
          maxLength={6}
          placeholder="Enter OTP"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          className="form-input"
          required
        />

        <button className="form-button" disabled={loading}>
          {loading ? "Verifying..." : "Verify OTP"}
        </button>

        {error && <p className="message-error">{error}</p>}
      </form>
    </div>
  );
};

export default OtpVerification;

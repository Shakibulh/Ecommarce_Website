import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./ForgetPassword.css";

const ForgetPassword = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!email) {
      setMessage({ type: "error", text: "Please enter your email" });
      return;
    }

    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch("http://localhost/ecommerce-backend/send_otp.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const text = await res.text();
      console.log("Raw server response:", text);

      // JSON parse করার চেষ্টা করো
      const data = JSON.parse(text);

      if (data.success) {
        setMessage({ type: "success", text: "OTP sent to your email!" });
        navigate("/verify-otp", { state: { email } });
      } else {
        setMessage({ type: "error", text: data.error || "Something went wrong." });
      }
    } catch (error) {
      setMessage({ type: "error", text: "Server error or invalid JSON response." });
      console.error("Error parsing JSON or network error:", error);
    }

    setLoading(false);
  };

  return (
    <div className="forget-container">
      <form className="forget-form" onSubmit={handleSubmit}>
        <h2 className="form-title">Forgot Password?</h2>
        <p className="form-subtitle">Enter your email to receive OTP.</p>

        <input
          type="email"
          placeholder="Your Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="form-input"
          required
        />

        <button type="submit" className="form-button" disabled={loading}>
          {loading ? "Sending..." : "Send OTP"}
        </button>

        {message && (
          <p
            className={message.type === "success" ? "message-success" : "message-error"}
          >
            {message.text}
          </p>
        )}
      </form>
    </div>
  );
};

export default ForgetPassword;

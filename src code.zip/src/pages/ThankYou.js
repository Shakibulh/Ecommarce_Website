import React from 'react';
import { Link } from 'react-router-dom';
import './Cart.css'; // styling একই রাখতে

const ThankYou = () => {
  return (
    <div className="product-detail-container">
      <h2>✅ Order Placed Successfully!</h2>
      <p>Thank you for your purchase.</p>

      <Link to="/" style={{ marginTop: '20px', display: 'inline-block' }}>
        ← Back to Home
      </Link>
    </div>
  );
};

export default ThankYou;

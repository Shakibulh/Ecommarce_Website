import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import BannerSlider from '../components/BannerSlider';
import staticBanner from '../assets/banner5.png';
import './Home.css';

const Home = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost/ecommerce-backend/get-products.php')
      .then(res => setProducts(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <>
      <div className="banner-row">
        {/* বাম দিকে: Full Width Slider */}
        <div className="left-banner">
          <BannerSlider />
        </div>

        {/* ডান দিকে: Full Width Static Banner */}
        <div className="right-banner">
          <img src={staticBanner} alt="Banner" />
        </div>
      </div>

      {/* প্রোডাক্ট গ্রিড */}
      <div className="product-grid">
        {products.map(product => (
          <Link
            to={`/product/${product.id}`}
            key={product.id}
            style={{ textDecoration: 'none', color: 'inherit' }}
          >
            <ProductCard product={product} />
          </Link>
        ))}
      </div>
    </>
  );
};

export default Home;


import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Checkout.css";

const Checkout = () => {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("card");

  // Dummy cart items — প্রকৃত প্রজেক্টে context বা props থেকে আনবে
  const cartItems = [
    { id: 1, quantity: 2, price: 100 },
    { id: 3, quantity: 1, price: 200 },
  ];

  const total = cartItems.reduce((sum, item) => sum + item.quantity * item.price, 0);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const orderData = {
      name,
      email,
      address,
      total,
      payment_method: paymentMethod,
      items: cartItems,
    };

    console.log("📤 Sending to server:", JSON.stringify(orderData));

    try {
      const res = await fetch("http://localhost/ecommerce-backend/submit_order.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData),
      });

      const text = await res.text();
      console.log("Server Response:", text);

      const data = JSON.parse(text);
      if (data.status === "success") {
        alert(data.message);

        // ফর্ম রিসেট
        setName("");
        setEmail("");
        setAddress("");
        setPaymentMethod("card");

        // সফল অর্ডারের পরে Homepage-এ রিডাইরেক্ট
        navigate("/");
      } else {
        alert("Order failed: " + (data.message || "Unknown error"));
      }
    } catch (err) {
      alert("Fetch error: " + err.message);
    }
  };

  return (
    <div className="checkout-container">
      <h2>Checkout</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </label>

        <label>
          Email:
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </label>

        <label>
          Address:
          <textarea value={address} onChange={(e) => setAddress(e.target.value)} required />
        </label>

        <div className="payment-method">
          <h4>Select Payment Method:</h4>
          {["card", "bkash", "nagad", "rocket"].map((method) => (
            <label key={method}>
              <input
                type="radio"
                name="paymentMethod"
                value={method}
                checked={paymentMethod === method}
                onChange={(e) => setPaymentMethod(e.target.value)}
              />
              {method.charAt(0).toUpperCase() + method.slice(1)}
            </label>
          ))}
        </div>

        <button type="submit">Place Order</button>
      </form>
    </div>
  );
};

export default Checkout;

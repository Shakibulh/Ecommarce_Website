import React from 'react';
import { useCart } from '../context/CartContext';
import { Link } from 'react-router-dom';
import './Cart.css';

const Cart = () => {
  const { cartItems, removeFromCart, updateQuantity } = useCart();

  const getTotal = () =>
    cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleDecrease = (id, currentQty) => {
    if (currentQty > 1) {
      updateQuantity(id, currentQty - 1);
    }
  };

  const handleIncrease = (id, currentQty) => {
    updateQuantity(id, currentQty + 1);
  };

  if (cartItems.length === 0) {
    return (
      <div className="cart-container">
        <h2>Your cart is empty 🛒</h2>
        <Link to="/">← Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="cart-container">
      <h2>Your Cart</h2>

      <table className="cart-table">
        <thead>
          <tr>
            <th>Image</th>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Subtotal</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {cartItems.map(item => (
            <tr key={item.id}>
              <td>
                <img
                  src={`http://localhost/ecommerce-backend/${item.image}`}
                  alt={item.name}
                  className="cart-image"
                />
              </td>
              <td>{item.name}</td>
              <td>৳{item.price}</td>
              <td>
                <div className="quantity-control">
                  <button onClick={() => handleDecrease(item.id, item.quantity)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => handleIncrease(item.id, item.quantity)}>+</button>
                </div>
              </td>
              <td>৳{(item.price * item.quantity).toFixed(2)}</td>
              <td>
                <button className="remove-button" onClick={() => removeFromCart(item.id)}>
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="cart-summary">
        <h3>Total: ৳{getTotal().toFixed(2)}</h3>
        <Link to="/checkout" className="checkout-button">Proceed to Checkout</Link>
        <Link to="/" className="continue-shopping">← Continue Shopping</Link>
      </div>
    </div>
  );
};

export default Cart;


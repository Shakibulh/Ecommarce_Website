import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";

const Login = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.email || !formData.password) {
      alert("Please fill all fields");
      return;
    }

    try {
      const res = await fetch("http://localhost/ecommerce-backend/login.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (data.success) {
        alert("Login successful!");
        localStorage.setItem("user", JSON.stringify(data.user));
        navigate("/");
      } else {
        alert("Login failed: " + (data.error || "Invalid credentials"));
      }
    } catch (error) {
      alert("Error submitting login");
      console.error(error);
    }
  };

  // Forget password handler (যদি দরকার হয়)
  const handleForgetPassword = () => {
    // এখানে তুমি চাইলে অন্য route এ নেভিগেট করতে পারো, বা মোডাল ওপেন করাতে পারো
    navigate("/forget-password"); // ধরছি তুমি একটি ফোরগেট পাসওয়ার্ড পেজ বানাবে
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2 className="form-title">Welcome Back</h2>
        <p className="form-subtitle">Login to your account</p>

        <input
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          type="email"
          className="form-input"
          required
        />
        <input
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          type="password"
          className="form-input"
          required
        />

        {/* Forget Password Link */}
        <p
          className="forget-password"
          onClick={handleForgetPassword}
          style={{ cursor: "pointer", color: "#0d47a1", marginBottom: "15px" }}
        >
          Forgot Password?
        </p>

        <button type="submit" className="form-button">
          Login
        </button>
        <p className="form-footer">
          Don't have an account? <a href="/register">Register</a>
        </p>
      </form>
    </div>
  );
};

export default Login;


import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./ForgetPassword.css";


const ResetPassword = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || "";

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  if (!email) {
    navigate("/forget-password");
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("http://localhost/ecommerce-backend/reset_password.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (data.success) {
        alert("Password reset successful! Please login.");
        navigate("/login");
      } else {
        setError(data.error || "Failed to reset password");
      }
    } catch {
      setError("Server error. Try again.");
    }
    setLoading(false);
  };

  return (
    <div className="forget-container">
      <form className="forget-form" onSubmit={handleSubmit}>
        <h2 className="form-title">Reset Password</h2>
        <p className="form-subtitle">Set your new password</p>

        <input
          type="password"
          placeholder="New Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="form-input"
          required
        />

        <input
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="form-input"
          required
        />

        <button className="form-button" disabled={loading}>
          {loading ? "Resetting..." : "Reset Password"}
        </button>

        {error && <p className="message-error">{error}</p>}
      </form>
    </div>
  );
};

export default ResetPassword;

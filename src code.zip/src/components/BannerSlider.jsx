import React, { useEffect, useState } from 'react';
import './BannerSlider.css';

const banners = [
  require('../assets/banner1.png'),
  require('../assets/banner2.png'),
  require('../assets/banner3.png'),
];

const BannerSlider = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % banners.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="banner-slider">
      <img src={banners[currentIndex]} alt={`Banner ${currentIndex + 1}`} />
    </div>
  );
};

export default BannerSlider;

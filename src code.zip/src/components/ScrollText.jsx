import React from "react";

const ScrollText = () => {
  return (
    <div style={{
      overflow: "hidden",
      whiteSpace: "nowrap",
      width: "100%",
      color: "#ffff66",
      backgroundColor: "#1a1a3b",
      fontSize: "14px",
      padding: "4px 0"
    }}>
      <div style={{
        display: "inline-block",
        paddingLeft: "100%",
        animation: "scroll-text 20s linear infinite"
      }}>
        ● New Offer: 20% off only for today! &nbsp;&nbsp;&nbsp;
        ● Free Shipping on all orders &nbsp;&nbsp;&nbsp;
        ● New Collection Just Arrived! Check it out now &nbsp;&nbsp;&nbsp;

      </div>

      <style>{`
        @keyframes scroll-text {
          0% { transform: translateX(0); }
          100% { transform: translateX(-100%); }
        }
      `}</style>
    </div>
  );
};

export default ScrollText;

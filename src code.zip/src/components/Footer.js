import React, { useState } from "react";
import "./Footer.css";
import bkashIcon from "../assets/bkash.png";
import nagadIcon from "../assets/nagad.png";
import rocketIcon from "../assets/rocket.png";
import cardsIcon from "../assets/cards.png";
import appstoreIcon from "../assets/appstore.png";
import playstoreIcon from "../assets/playstore.png";
import appgalleryIcon from "../assets/appgallery.png";
import verifiedIcon from "../assets/verified.png";

const Footer = () => {
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [careType, setCareType] = useState(null);
  const [aboutType, setAboutType] = useState(null);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const toggleModal = () => {
    setShowModal(!showModal);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    const formData = {
      name: e.target.name.value,
      email: e.target.email.value,
      message: e.target.message.value,
    };

    fetch("http://localhost/ecommerce-backend/submit_enquiry.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    })
      .then((res) => res.json())
      .then((data) => {
        alert(data.message || "Submitted successfully!");
        setShowModal(false);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error:", err);
        alert("Submission failed. Please try again.");
        setLoading(false);
      });
  };

  const careTypeHeading = (type) => {
    const headings = {
      help: "Help Center",
      buy: "How to Buy",
      returns: "Returns & Refunds",
      contact: "Contact Us",
      terms: "Terms & Conditions",
      complaint: "Complaint Management",
    };
    return headings[type] || "";
  };

  const careContent = {
    help: `🆘 Help Center:

Find answers to your most common questions. Our support team is available 24/7.`,
    buy: `🛒 How to Buy:

1. Browse products
2. Add to cart
3. Proceed to checkout
4. Select payment method
5. Confirm order`,
    returns: `🔄 Returns & Refunds:

You can return products within 7 days of delivery.
Refunds are processed within 5 business days.`,
    contact: `📞 Contact Us:

Phone: 123-456-7890
Email: support@yourstore.com
Facebook: fb.com/yourstore`,
    terms: `📜 Terms & Conditions:

By using our website, you agree to our terms including:
• No fake orders
• No abusive language
• Legal compliance`,
    complaint: `🧾 Complaint Management:

File your complaint through:
• Live Chat
• Email Support
• Phone

We take each complaint seriously.`,
  };

  const aboutTypeHeading = (type) => {
    const headings = {
      about: "About Us",
      payments: "Digital Payments",
      blog: "Our Blog",
      privacy: "Privacy Policy",
      affiliate: "Affiliate Program",
    };
    return headings[type] || "";
  };

  const aboutContent = {
    about: `🛍️ About Us:

We are a trusted eCommerce store in Bangladesh offering quality products with quick delivery.`,
    payments: `💳 Digital Payments:

We support:
• bKash
• Nagad
• Rocket
• Visa & Mastercard`,
    blog: `📝 Blog:

Visit our blog for deals, tips, and reviews.
🔗 yourstore.com/blog`,
    privacy: `🔐 Privacy Policy:

Your data is safe with us. We never sell personal information.`,
    affiliate: `🤝 Affiliate Program:

Earn money by referring customers.
✅ High commission
✅ Real-time tracking`,
  };

  return (
    <>
      <footer className="footer">
        <div className="footer-top">
          <div className="footer-section">
            <h4>Customer Care</h4>
            <ul>
              <li onClick={() => setCareType("help")}>Help Center</li>
              <li onClick={() => setCareType("buy")}>How to Buy</li>
              <li onClick={() => setCareType("returns")}>Returns & Refunds</li>
              <li onClick={() => setCareType("contact")}>Contact Us</li>
              <li onClick={() => setCareType("terms")}>Terms & Conditions</li>
              <li onClick={() => setCareType("complaint")}>Complaint Management</li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>About Store</h4>
            <ul>
              <li onClick={() => setAboutType("about")}>About Us</li>
              <li onClick={() => setAboutType("payments")}>Digital Payments</li>
              <li onClick={() => setAboutType("blog")}>Blog</li>
              <li onClick={() => setAboutType("privacy")}>Privacy Policy</li>
              <li onClick={() => setAboutType("affiliate")}>Affiliate Program</li>
            </ul>
          </div>

          <div className="footer-section">
            <h4>Download App</h4>
            <div className="app-links">
              <img src={appstoreIcon} alt="appstore" />
              <img src={playstoreIcon} alt="playstore" />
              <img src={appgalleryIcon} alt="appgallery" />
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <div className="payment-section">
            <h5>Payment Methods</h5>
            <div className="payment-icons">
              <img src={cardsIcon} alt="cards" />
              <img src={bkashIcon} alt="bKash" />
              <img src={nagadIcon} alt="nagad" />
              <img src={rocketIcon} alt="rocket" />
            </div>
          </div>

          <div className="security-section">
            <h5>Verified By</h5>
            <img src={verifiedIcon} alt="verified" />
          </div>

          <div className="registration-section">
            <h5>Bangladesh</h5>
            <p>Registration ID: <strong>16107319874587</strong></p>
          </div>
        </div>
      </footer>

      {/* Floating Buttons */}
      <div className="floating-buttons">
        <button className="float-btn" onClick={toggleModal}>
          <span className="float-icon">✉️</span> Enquire
        </button>
        <button className="float-btn" onClick={scrollToTop}>
          <span className="float-icon">⬆️</span> Top
        </button>
      </div>

      {/* Enquiry Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={toggleModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={toggleModal}>✖</button>
            <h2>Contact Us</h2>
            <form className="contact-form" onSubmit={handleSubmit}>
              <label>
                Name:
                <input type="text" name="name" placeholder="Your Name" required />
              </label>
              <label>
                Email:
                <input type="email" name="email" placeholder="Your Email" required />
              </label>
              <label>
                Message:
                <textarea name="message" placeholder="Your Message" rows="4" required />
              </label>
              <button type="submit" className="send-btn" disabled={loading}>
                {loading ? "Sending..." : "Send Message"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Customer Care Modal */}
      {careType && (
        <div className="modal-overlay" onClick={() => setCareType(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setCareType(null)}>✖</button>
            <h2>{careTypeHeading(careType)}</h2>
            <p style={{ whiteSpace: "pre-line" }}>{careContent[careType]}</p>
          </div>
        </div>
      )}

      {/* About Store Modal */}
      {aboutType && (
        <div className="modal-overlay" onClick={() => setAboutType(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setAboutType(null)}>✖</button>
            <h2>{aboutTypeHeading(aboutType)}</h2>
            <p style={{ whiteSpace: "pre-line" }}>{aboutContent[aboutType]}</p>
          </div>
        </div>
      )}
    </>
  );
};

export default Footer;

// src/components/Navbar.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaSearch } from "react-icons/fa";
import logo from "../assets/logo.png";
import ScrollText from "./ScrollText";

const Navbar = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));
  const [searchTerm, setSearchTerm] = useState("");

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/");
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?query=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  return (
    <>
      {/* 🟡 Scrolling Text Bar */}
      <ScrollText />

      {/* 🔴 Main Navbar */}
      <nav style={{
        backgroundColor: "#f85606",
        padding: "10px 20px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        color: "#fff"
      }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <img src={logo} alt="Logo" style={{ height: "30px" }} />
          <strong style={{ fontSize: "20px" }}>MyShope</strong>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} style={{
          flex: 1,
          maxWidth: "450px",
          margin: "10px 30px 10px 30px",
          display: "flex"
        }}>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search in MyShope"
            style={{
              width: "100%",
              padding: "8px",
              border: "none",
              borderRadius: "4px 0 0 4px",
              outline: "none"
            }}
          />
          <button type="submit" style={{
            backgroundColor: "#f57224",
            padding: "8px 12px",
            border: "none",
            borderRadius: "0 4px 4px 0",
            color: "white",
            cursor: "pointer"
          }}>
            <FaSearch />
          </button>
        </form>

        {/* Menu */}
        <div style={{
          display: "flex",
          alignItems: "center",
          gap: "15px",
          flexWrap: "wrap"
        }}>
          <Link to="/" style={{ color: "white", textDecoration: "none" }}>Home</Link>
          <Link to="/cart" style={{ color: "white", textDecoration: "none" }}>Cart</Link>
          <Link to="/checkout" style={{ color: "white", textDecoration: "none" }}>Checkout</Link>

          {user ? (
            <>
              <span style={{ color: "white" }}>Welcome, {user.name}</span>
              <button
                onClick={handleLogout}
                style={{
                  backgroundColor: "transparent",
                  color: "white",
                  border: "1px solid white",
                  padding: "5px 10px",
                  borderRadius: "4px",
                  cursor: "pointer"
                }}
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/register" style={{ color: "white", textDecoration: "none" }}>Register</Link>
              <Link to="/login" style={{ color: "white", textDecoration: "none" }}>Login</Link>
            </>
          )}
        </div>
      </nav>
    </>
  );
};

export default Navbar;

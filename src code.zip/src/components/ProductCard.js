import React from 'react';
import './ProductCard.css';

const ProductCard = ({ product }) => {
  return (
    <div className="product-card">
      <img
        src={`http://localhost/ecommerce-backend/${product.image}`}
        alt={product.name}
      />
      <h3>{product.name}</h3>
      <p>{product.description}</p>
      <strong>৳{Number(product.price).toFixed(2)}</strong>
    </div>
  );
};

export default ProductCard;
